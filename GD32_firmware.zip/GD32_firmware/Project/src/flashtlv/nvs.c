#include "nvs.h"
#include <stddef.h>
#include <stdbool.h>
#include "rtklibc.h"
#include "flash_tlv.h"

#define NVS_TLV1_MAJOR_SEC    0x0800F800
#define NVS_TLV1_MINOR_SEC    0x0800FC00
#define NVS_TLV1_PART_SIZE    1024

static tlv_sector_t nvs1_sec = {0u, 0u, 0u, 0u, 0u, 0u};

// @param[in] name support "nvs1" and "nvs2"
nvs_handle_t nvs_open(const char* name) {
    int len = rt_strlen(name);
    if(len != 4) {
        return NULL;
    }
    if(rt_strncmp(name, "nvs1", 4) != 0) {
        return NULL;
    }
    if(nvs1_sec.major_sector == 0) {
        flash_tlv_init(&nvs1_sec, NVS_TLV1_MAJOR_SEC, NVS_TLV1_MINOR_SEC, NVS_TLV1_PART_SIZE);
    }
    return (void *)&nvs1_sec;
}

nvs_err_t nvs_set_blob(nvs_handle_t handle, uint16_t key, const uint8_t* value, uint32_t length) {
    if(handle == NULL) {
        return NVS_ERR_INVALID_HANDLE;
    }
    
    if((length > 65534) || (length & 0x1) || (length == 0)) {
        return NVS_ERR_INVALID_LENGTH;
    }
    
    bool success = flash_tlv_append((tlv_sector_t *)handle, key, value, (uint16_t)length);
    
    return success ? NVS_ERR_OK : NVS_ERR_NOT_ENOUGH_SPACE;
}

nvs_err_t nvs_get_blob(nvs_handle_t handle, uint16_t key, uint8_t* out_value, uint32_t* length) {
    bool success;
    tlv_block_t blk;
    uint32_t readin;
    uint16_t tlvlen;
    
    if(handle == NULL) {
        return NVS_ERR_INVALID_HANDLE;
    }
    
    success = flash_tlv_query((tlv_sector_t *)handle, key, &blk);
    if(!success) {
        return NVS_ERR_NOT_FOUND;
    }
    // Win32API-style length queries
    if(out_value == NULL) {
        if(length != NULL) {
            *length = blk.length;
        }
        return NVS_ERR_OK;
    }
    if(length == NULL || (*length < blk.length)) {
        return NVS_ERR_INVALID_LENGTH;
    }
    
    success = flash_tlv_verify(&blk);
    if(!success) {
        return NVS_ERR_VERIFY_FAIL;
    }

    tlvlen = (uint16_t)(*length & 0xFFFF);
    if(tlvlen > blk.length) {
        tlvlen = blk.length;
    }
    readin = flash_tlv_read(&blk, out_value, 0, tlvlen);

    *length = readin;
    
    return (readin == tlvlen) ? NVS_ERR_OK : NVS_ERR_READ_INCPLT;
}

nvs_err_t nvs_erase_key(nvs_handle_t handle, uint16_t key) {
    if(handle == NULL) {
        return NVS_ERR_INVALID_HANDLE;
    }
    
    bool success = flash_tlv_delete((tlv_sector_t *)handle, key);
    
    return success ? NVS_ERR_OK : NVS_ERR_NOT_FOUND;
}

nvs_err_t nvs_set_i16(nvs_handle_t handle, uint16_t key, int16_t value) {
    return nvs_set_blob(handle, key, (const uint8_t*)&value, sizeof(int16_t));
}

nvs_err_t nvs_get_i16(nvs_handle_t handle, uint16_t key, int16_t* out_value) {
    uint32_t length = sizeof(int16_t);
    return nvs_get_blob(handle, key, (uint8_t*)out_value, &length);
}

int16_t nvs_get_i16_or_default(nvs_handle_t handle, uint16_t key, int16_t default_value) {
    int16_t value;
    nvs_err_t err = nvs_get_i16(handle, key, &value);
    return (err == NVS_ERR_OK) ? value : default_value;
}

nvs_err_t nvs_set_u16(nvs_handle_t handle, uint16_t key, uint16_t value) {
    return nvs_set_blob(handle, key, (const uint8_t*)&value, sizeof(uint16_t));
}

nvs_err_t nvs_get_u16(nvs_handle_t handle, uint16_t key, uint16_t* out_value) {
    uint32_t length = sizeof(uint16_t);
    return nvs_get_blob(handle, key, (uint8_t*)out_value, &length);
}

uint16_t nvs_get_u16_or_default(nvs_handle_t handle, uint16_t key, uint16_t default_value) {
    uint16_t value;
    nvs_err_t err = nvs_get_u16(handle, key, &value);
    return (err == NVS_ERR_OK) ? value : default_value;
}

nvs_err_t nvs_set_i32(nvs_handle_t handle, uint16_t key, int32_t value) {
    return nvs_set_blob(handle, key, (const uint8_t*)&value, sizeof(int32_t));
}

nvs_err_t nvs_get_i32(nvs_handle_t handle, uint16_t key, int32_t* out_value) {
    uint32_t length = sizeof(int32_t);
    return nvs_get_blob(handle, key, (uint8_t*)out_value, &length);
}

int32_t nvs_get_i32_or_default(nvs_handle_t handle, uint16_t key, int32_t default_value) {
    int32_t value;
    nvs_err_t err = nvs_get_i32(handle, key, &value);
    return (err == NVS_ERR_OK) ? value : default_value;
}

nvs_err_t nvs_set_u32(nvs_handle_t handle, uint16_t key, uint32_t value) {
    return nvs_set_blob(handle, key, (const uint8_t*)&value, sizeof(uint32_t));
}

nvs_err_t nvs_get_u32(nvs_handle_t handle, uint16_t key, uint32_t* out_value) {
    uint32_t length = sizeof(uint32_t);
    return nvs_get_blob(handle, key, (uint8_t*)out_value, &length);
}

uint32_t nvs_get_u32_or_default(nvs_handle_t handle, uint16_t key, uint32_t default_value) {
    uint32_t value;
    nvs_err_t err = nvs_get_u32(handle, key, &value);
    return (err == NVS_ERR_OK) ? value : default_value;
}

nvs_err_t nvs_get_blob_or_default(nvs_handle_t handle, uint16_t key, uint8_t* out_value, uint32_t* length, const char *default_value) {
    uint32_t len = 0;
    if(length != NULL) {
        len = *length;
    }
    nvs_err_t err = nvs_get_blob(handle, key, out_value, length);
    if(err == NVS_ERR_NOT_FOUND && len) {
        rt_memcpy(out_value, default_value, len);
    }
    return err;
}
