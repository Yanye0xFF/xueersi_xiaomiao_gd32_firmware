/*
 * flash_tlv.h
 * @brief
 * Created on: Apr 10, 2022
 * Author: Yanye
 */

#ifndef _FLASH_TLV_H_
#define _FLASH_TLV_H_

#include "stdint.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FLASH_TLV_DEBUG        0
#define FLASH_TLV_USE_CACHE    0

#define INVALID_ADDRESS        0xFFFFFFFF

typedef enum {
    TLV_RESULT_OK = 0,
    TLV_RESULT_NOT_FOUND,
    TLV_NO_VALID_SECTOR,
    TLV_META_SPACE_LOW,
    TLV_DATA_SPACE_LOW,
} tlv_err_t;

#define TLV_MEAT_SIZE          12u

#define HEADER_EMPTY_TLV          0xFFFF
#define HEADER_VALID_TLV          0xAA55

#define TLV_STATE_NONE            0xFFFF
#define TLV_STATE_WRITE           0xCB59
#define TLV_STATE_DELETE          0xDEB7

typedef struct _tlv_block {
    // 0x55 0xaa
    uint16_t header;
    uint16_t sts_write;  // TLV_STATE_NONE or TLV_STATE_WRITE
    uint16_t sts_delete; // TLV_STATE_NONE or TLV_STATE_DELETE
    uint16_t tag;
    uint16_t length;
    uint16_t crc16;
    // no store
    uint32_t entity;
} tlv_block_t;

typedef struct _tlv_sector {
    uint32_t major_sector;
    uint32_t minor_sector;
    uint16_t sector_size;
    uint16_t dirty_blocks;
    uint32_t work_sector;
    uint32_t mark_address;
} tlv_sector_t;

#define TLV_SECTOR_TAG            0xCAEE
#define TLV_VERSION_MIN           0x0000
#define TLV_VERSION_MAX           0xFFFF
#define TLV_SECTOR_HEADER_SIZE    4

typedef struct _tlv_sector_header {
    uint16_t tag;
    uint16_t version;
} tlv_sector_header_t;

void flash_tlv_init(tlv_sector_t *sector, uint32_t major, uint32_t minor, uint16_t size);

bool flash_tlv_append(tlv_sector_t *sector, uint16_t tag, const uint8_t *data, uint16_t length);

bool flash_tlv_query(tlv_sector_t *sector, uint16_t tag, tlv_block_t *block);

uint32_t flash_tlv_read(tlv_block_t *block, uint8_t *buffer, uint16_t offset, uint16_t length);

bool flash_tlv_verify(tlv_block_t *block);

bool flash_tlv_delete(tlv_sector_t *sector, uint16_t tag);

#ifdef __cplusplus
}
#endif

#endif
