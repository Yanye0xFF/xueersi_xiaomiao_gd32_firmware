/*
 * flash_tlv.c
 * @brief
 * Created on: Apr 10, 2022
 * Author: Yanye
 */
#include "flash_tlv.h"
#include "drv_intflash.h"
#include <stdbool.h>
#include "rtklibc.h"
#include "crc.h"

#define TLV_BLOCK_APPEND    0
#define TLV_BLOCK_QUERY     1
#define TLV_BLOCK_DELETE    2

static const uint16_t tlv_del_flag = TLV_STATE_DELETE;

static tlv_err_t search_tlv(tlv_sector_t *sector, tlv_block_t *block, uint8_t flag);

static uint32_t flash_tlv_gc(tlv_sector_t *sector);

void flash_tlv_init(tlv_sector_t *sector, uint32_t major, uint32_t minor, uint16_t size) {
    sector->major_sector = major;
    sector->minor_sector = minor;
    sector->sector_size = size;

    sector->work_sector = INVALID_ADDRESS;
    sector->mark_address = 0;
    sector->dirty_blocks = 0;
}

void flash_tlv_format(tlv_sector_t *sector) {
    const static uint32_t sector_header = (TLV_VERSION_MIN << 16) | TLV_SECTOR_TAG;
    
    flash_erase(sector->major_sector, (sector->sector_size / FMC_PAGE_SIZE));
    flash_erase(sector->minor_sector, (sector->sector_size / FMC_PAGE_SIZE));
    
    flash_write(sector->major_sector, sizeof(uint32_t), (uint8_t *)&sector_header);
    sector->work_sector = sector->major_sector;
}

// @param[in] tag record id number, from 0 to 65535
// @param[in] length must be 2bytes aligned, 2 ~ 65534
bool flash_tlv_append(tlv_sector_t *sector, uint16_t tag, const uint8_t *data, uint16_t length) {
    tlv_err_t status;
    tlv_block_t block;
    uint32_t count;
    uint16_t crc16;
    uint8_t buffer[32];
    uint32_t offset = 0;
    // align up
    length = length + (length & 0x1);

    block.tag = tag;
    block.length = length;
    status = search_tlv(sector, &block, TLV_BLOCK_APPEND);
    if(status == TLV_RESULT_OK) {
        goto LAB_WRITE_TLV;
    }
    count = flash_tlv_gc(sector);
    if(count < (TLV_MEAT_SIZE + length)) {
        return false;
    }
    status = search_tlv(sector, &block, TLV_BLOCK_APPEND);
    if(status != TLV_RESULT_OK) {
        return false;
    }

    LAB_WRITE_TLV:
    crc16 = crc16_modbus(0x00, (const uint8_t *)&tag, sizeof(uint16_t));
    crc16 = crc16_modbus(crc16, (const uint8_t *)&length, sizeof(uint16_t));
    crc16 = crc16_modbus(crc16, data, length);

    block.header = HEADER_VALID_TLV;
    block.sts_write = TLV_STATE_WRITE;
    block.sts_delete = TLV_STATE_NONE;
    block.crc16 = crc16;
    
    flash_write(block.entity, TLV_MEAT_SIZE, (uint8_t *)&block);
    flash_write(block.entity + TLV_MEAT_SIZE, length, data);
    
    rt_memcpy(buffer, (void *)block.entity, TLV_MEAT_SIZE);
    if(rt_memcmp(buffer, (uint8_t *)&block, TLV_MEAT_SIZE) != 0) {
        flash_write(block.entity + 4u, sizeof(uint16_t), (const uint8_t *)&tlv_del_flag);
        return false;
    }
    
    do {
        count = (length > sizeof(buffer)) ? sizeof(buffer) : length;
        rt_memcpy(buffer, (void *)(block.entity + TLV_MEAT_SIZE + offset), count);
        if(rt_memcmp(buffer, (data + offset), count) != 0) {
            flash_write(block.entity + 4u, sizeof(uint16_t), (const uint8_t *)&tlv_del_flag);
            return false;
        }
        offset += count;
        length -= count;
    }while(length);
    
    block.entity += TLV_MEAT_SIZE;

    if(sector->mark_address != 0) {
        flash_write((sector->mark_address + 4), sizeof(uint16_t), (const uint8_t *)&tlv_del_flag);
        sector->mark_address = 0;
        sector->dirty_blocks++;
    }

    return true;
}

bool flash_tlv_query(tlv_sector_t *sector, uint16_t tag, tlv_block_t *block) {
    tlv_err_t err;

    block->tag = tag;
    err = search_tlv(sector, block, TLV_BLOCK_QUERY);

    return (err == TLV_RESULT_OK);
}

uint32_t flash_tlv_read(tlv_block_t *block, uint8_t *buffer, uint16_t offset, uint16_t length) {
    if(offset >= block->length) {
        return 0;
    }
    if((offset + length) > block->length) {
        length = block->length - offset;
    }
    rt_memcpy(buffer, (void *)(block->entity + offset), length);
    return length;
}

bool flash_tlv_verify(tlv_block_t *block) {
    uint16_t crc16;
    uint8_t buffer[32];
    uint32_t trunk;
    uint32_t offset = 0;
    uint32_t length = block->length;

    rt_memcpy(buffer, &(block->tag), sizeof(uint16_t));
    rt_memcpy(buffer + 2, &(block->length), sizeof(uint16_t));
    crc16 = crc16_modbus(0x00, buffer, 4);

    do {
        trunk = (length > 32) ? 32 : length;
        rt_memcpy(buffer, (void *)(block->entity + offset), trunk);
        crc16 = crc16_modbus(crc16, buffer, trunk);
        offset += trunk;
        length -= trunk;
    }while(length);
    
    return (block->crc16 == crc16);
}

bool flash_tlv_delete(tlv_sector_t *sector, uint16_t tag) {
    tlv_err_t err;
    tlv_block_t block;

    block.tag = tag;
    err = search_tlv(sector, &block, TLV_BLOCK_DELETE);
    return (err == TLV_RESULT_OK);
}

static bool find_valid_sector(tlv_sector_t *tlv_sec) {
    tlv_sector_header_t  header_major;
    tlv_sector_header_t  header_minor;
    
    rt_memcpy((uint8_t *)&header_major, (void *)(tlv_sec->major_sector), TLV_SECTOR_HEADER_SIZE);
    rt_memcpy((uint8_t *)&header_minor, (void *)(tlv_sec->minor_sector), TLV_SECTOR_HEADER_SIZE);

    if((header_major.tag == TLV_SECTOR_TAG) && (header_minor.tag == TLV_SECTOR_TAG)) {
        if(header_major.version == TLV_VERSION_MAX && header_minor.version == TLV_VERSION_MIN) {
            tlv_sec->work_sector = tlv_sec->minor_sector;
        }else if(header_major.version == TLV_VERSION_MIN && header_minor.version == TLV_VERSION_MAX) {
            tlv_sec->work_sector = tlv_sec->major_sector;
        }else {
            tlv_sec->work_sector = (header_major.version > header_minor.version) ?
                    tlv_sec->major_sector : tlv_sec->minor_sector;
        }
    }else if((header_major.tag != TLV_SECTOR_TAG) && (header_minor.tag != TLV_SECTOR_TAG)) {
        flash_tlv_format(tlv_sec);
    }else if(header_major.tag == TLV_SECTOR_TAG) {
        tlv_sec->work_sector = tlv_sec->major_sector;
    }else if(header_minor.tag == TLV_SECTOR_TAG) {
        tlv_sec->work_sector = tlv_sec->minor_sector;
    }
    return (tlv_sec->work_sector != INVALID_ADDRESS);
}

static bool tlv_is_bad_block(uint32_t current_addr, uint32_t end_addr, tlv_block_t *block) {
    if(block->header == HEADER_EMPTY_TLV) {
        return false;
    }
    if(block->header != HEADER_VALID_TLV) {
        return true;
    }
    if((block->sts_write == TLV_STATE_NONE) || (block->length == 0xFFFF)) {
        return true;
    }
    uint32_t available = (end_addr - current_addr - TLV_MEAT_SIZE);
    return (block->length > available) ? true : false;
}

static tlv_err_t search_tlv(tlv_sector_t *sector, tlv_block_t *block, uint8_t flag) {
    bool status = true;
    tlv_block_t temp_block;
    uint32_t start_addr, end_addr;
    
    if(sector->work_sector == INVALID_ADDRESS) {
        status = find_valid_sector(sector);
    }
    if(!status) {
        return TLV_NO_VALID_SECTOR;
    }
    start_addr = (sector->work_sector + TLV_SECTOR_HEADER_SIZE);
    end_addr = (sector->work_sector + sector->sector_size);
    sector->dirty_blocks = 0;
    sector->mark_address = 0;

    while(start_addr < end_addr) {
        if((start_addr + TLV_MEAT_SIZE) > end_addr) {
            return TLV_META_SPACE_LOW;
        }
        rt_memcpy(&temp_block, (void *)start_addr, TLV_MEAT_SIZE);
        if(tlv_is_bad_block(start_addr, end_addr, &temp_block)) {
            start_addr += TLV_MEAT_SIZE;
            sector->dirty_blocks++;
            continue;
        }
        
        if(temp_block.header == HEADER_VALID_TLV) {
            if(temp_block.sts_delete != TLV_STATE_NONE) {
                sector->dirty_blocks++;
            }
            if(temp_block.tag == block->tag) {
                if((flag == TLV_BLOCK_APPEND) && (temp_block.sts_delete != TLV_STATE_DELETE)) {
                    if(sector->mark_address == 0) {
                        sector->mark_address = start_addr;
                    }else {
                        flash_write((sector->mark_address + 4), sizeof(uint16_t), (const uint8_t *)&flag);
                        sector->mark_address = start_addr;
                        sector->dirty_blocks++;
                    }
                }else if((flag == TLV_BLOCK_QUERY)
                    && (temp_block.sts_write == TLV_STATE_WRITE)
                    && (temp_block.sts_delete == TLV_STATE_NONE)) {
                        
                    rt_memcpy(block, &temp_block, TLV_MEAT_SIZE);
                    block->entity = (start_addr + TLV_MEAT_SIZE);
                    return TLV_RESULT_OK;
                    
                }else if((flag == TLV_BLOCK_DELETE) && (temp_block.sts_delete == TLV_STATE_NONE)) {
                    flash_write((start_addr + 4), sizeof(uint16_t), (const uint8_t *)&tlv_del_flag);
                    sector->dirty_blocks++;
                    return TLV_RESULT_OK;
                }
            }
            start_addr += (TLV_MEAT_SIZE + temp_block.length);
            
        }else if(temp_block.header == HEADER_EMPTY_TLV) {
            if(flag == TLV_BLOCK_APPEND) {
                if((end_addr - start_addr) >= (TLV_MEAT_SIZE + block->length)) {
                    block->entity = start_addr;
                    return TLV_RESULT_OK;
                }else {
                    return TLV_DATA_SPACE_LOW;
                }
            }
            // flag = 'TLV_BLOCK_QUERY' or 'TLV_BLOCK_DELETE'
            break;
        }
    }
    return TLV_RESULT_NOT_FOUND;
}

static uint32_t flash_tlv_gc(tlv_sector_t *sector) {
    uint32_t swap_sector;
    uint32_t read_addr, write_addr, end_addr;
    tlv_sector_header_t sector_header;

    tlv_block_t temp_block;
    uint8_t buffer[32];
    uint32_t trunk;

    if(sector->dirty_blocks == 0) {
        return 0;
    }
    swap_sector = (sector->work_sector == sector->major_sector) ?
                  sector->minor_sector : sector->major_sector;

    read_addr = (sector->work_sector + TLV_SECTOR_HEADER_SIZE);
    end_addr = (sector->work_sector + sector->sector_size);
    write_addr = (swap_sector + TLV_SECTOR_HEADER_SIZE);

    flash_erase(swap_sector, (sector->sector_size / FMC_PAGE_SIZE));

    while(read_addr < end_addr) {
        if((read_addr + TLV_MEAT_SIZE) > end_addr) {
            break;
        }
        rt_memcpy((uint8_t *)&temp_block, (void *)read_addr, TLV_MEAT_SIZE);
        if(tlv_is_bad_block(read_addr, end_addr, &temp_block)) {
            read_addr += TLV_MEAT_SIZE;
            continue;
        }
        if((temp_block.sts_write == TLV_STATE_WRITE) && (temp_block.sts_delete == TLV_STATE_NONE)) {
            flash_write(write_addr, TLV_MEAT_SIZE, (const uint8_t *)&temp_block);
            write_addr += TLV_MEAT_SIZE;
            read_addr += TLV_MEAT_SIZE;
            
            do{
                trunk = (temp_block.length > sizeof(buffer)) ? sizeof(buffer) : temp_block.length;

                rt_memcpy(buffer, (void *)read_addr, trunk);
                flash_write(write_addr, trunk, (const uint8_t *)buffer);
                
                read_addr += trunk;
                write_addr += trunk;
                temp_block.length -= trunk;
            }while(temp_block.length);
        }else {
            read_addr += (TLV_MEAT_SIZE + temp_block.length);
        }
    }

    rt_memcpy((uint8_t *)&sector_header, (void *)sector->work_sector, TLV_SECTOR_HEADER_SIZE);
    
    if(sector_header.version == TLV_VERSION_MAX) {
        sector_header.version = TLV_VERSION_MIN;
    }else {
        sector_header.version++;
    }
    flash_write(swap_sector, TLV_SECTOR_HEADER_SIZE, (const uint8_t *)&sector_header);
    sector->work_sector = swap_sector;

    end_addr = (swap_sector + sector->sector_size);
    
    return (end_addr - write_addr);
}
