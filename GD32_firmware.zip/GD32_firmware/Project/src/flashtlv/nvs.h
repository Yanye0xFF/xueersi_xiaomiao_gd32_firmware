/*
 * SPDX-FileCopyrightText: 2015-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef ESP_NVS_H
#define ESP_NVS_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define NVS_ERR_OK                  0

#define NVS_ERR_INVALID_ARG         100
#define NVS_ERR_INVALID_HANDLE      101
#define NVS_ERR_NOT_ENOUGH_SPACE    102
#define NVS_ERR_REMOVE_FAILED       103
#define NVS_ERR_VALUE_TOO_LONG      104
#define NVS_ERR_INVALID_LENGTH      105
#define NVS_ERR_NOT_FOUND           106
#define NVS_ERR_VERIFY_FAIL         107
#define NVS_ERR_READ_INCPLT         108

typedef uint32_t nvs_err_t;

/**
 * Opaque pointer type representing non-volatile storage handle
 */
typedef void * nvs_handle_t;

/**
 * @brief      Open non-volatile storage with a given namespace from the default NVS partition
 *
 * Multiple internal ESP-IDF and third party application modules can store
 * their key-value pairs in the NVS module. In order to reduce possible
 * conflicts on key names, each module can use its own namespace.
 * The default NVS partition is the one that is labelled "nvs" in the partition
 * table.
 *
 * @param[in]  name   Namespace name. Maximum length is (NVS_KEY_NAME_MAX_SIZE-1) characters. Shouldn't be empty.
 * @param[out] out_handle       If successful (return code is zero), handle will be
 *                              returned in this argument.
 *
 * @return
 *             - If successful, handle will be returned in this argument.
 */
nvs_handle_t nvs_open(const char* name);

/**
 * @brief       set variable length binary value for given key
 *
 *
 * @param[in]  handle  Handle obtained from nvs_open function.
 * @param[in]  key     Key name, from 0 to 65535.
 * @param[in]  value   The value to set.
 * @param[in]  length  length of binary value to set, in bytes,
 *                     must be 2bytes aligned, 2 ~ 65534
 * @return
 *             - NVS_ERR_OK if value was set successfully
 *             - NVS_ERR_INVALID_HANDLE if handle has been closed or is NULL
 *             - NVS_ERR_NOT_ENOUGH_SPACE if there is not enough space in the
 *               underlying storage to save the value
 *             - NVS_ERR_REMOVE_FAILED if the value wasn't updated because flash
 *               write operation has failed. The value was written however, and
 *               update will be finished after re-initialization of nvs, provided that
 *               flash operation doesn't fail again.
 *             - NVS_ERR_VALUE_TOO_LONG if the value is too long
 */
nvs_err_t nvs_set_blob(nvs_handle_t handle, uint16_t key, const uint8_t* value, uint32_t length);


/**
 * @brief      get blob value for given key
 *
 * These functions retrieve the data of an entry, given its key. If key does not
 * exist, an error is returned.
 *
 * In case of any error, out_value is not modified.
 *
 * All functions expect out_value to be a pointer to an already allocated variable
 * of the given type.
 *
 * nvs_get_blob functions support WinAPI-style length queries.
 * To get the size necessary to store the value, call nvs_get_blob
 * with zero out_value and non-zero pointer to length. Variable pointed to
 * by length argument will be set to the required length. For nvs_get_str,
 * this length includes the zero terminator. When calling nvs_get_str and
 * nvs_get_blob with non-zero out_value, length has to be non-zero and has to
 * point to the length available in out_value.
 * It is suggested that nvs_get/set_str is used for zero-terminated C strings, and
 * nvs_get/set_blob used for arbitrary data structures.
 *
 *
 * @param[in]     handle     Handle obtained from nvs_open function.
 * @param[in]     key        Key name, from 0 to 65535.
 * @param[out]    out_value  Pointer to the output value.
 *                           May be NULL for nvs_get_str and nvs_get_blob, in this
 *                           case required length will be returned in length argument.
 * @param[inout]  length     A non-zero pointer to the variable holding the length of out_value.
 *                           In case out_value a zero, will be set to the length
 *                           required to hold the value. In case out_value is not
 *                           zero, will be set to the actual length of the value
 *                           written. For nvs_get_str this includes zero terminator.
 *
 * @return
 *             - NVS_ERR_OK if the value was retrieved successfully
 *             - NVS_ERR_NOT_FOUND if the requested key doesn't exist
 *             - NVS_ERR_INVALID_HANDLE if handle has been closed or is NULL
 *             - NVS_ERR_VERIFY_FAIL 
 *             - NVS_ERR_READ_INCPLT
 *             - NVS_ERR_INVALID_LENGTH if \c length is not sufficient to store data
 */
nvs_err_t nvs_get_blob(nvs_handle_t handle, uint16_t key, uint8_t* out_value, uint32_t* length);

/**
 * @brief      Erase key-value pair with given key name.
 * @param[in]  handle  Storage handle obtained with nvs_open.
 * @param[in]  key     Key name, from 0 to 65535.
 * @return
 *              - NVS_ERR_OK if erase operation was successful
 *              - NVS_ERR_INVALID_HANDLE if handle has been closed or is NULL
 *              - NVS_ERR_NOT_FOUND if the requested key doesn't exist
 */
nvs_err_t nvs_erase_key(nvs_handle_t handle, uint16_t key);

nvs_err_t nvs_set_i16 (nvs_handle_t handle, uint16_t key, int16_t value);
nvs_err_t nvs_get_i16 (nvs_handle_t handle, uint16_t key, int16_t* out_value);
int16_t nvs_get_i16_or_default(nvs_handle_t handle, uint16_t key, int16_t default_value);

nvs_err_t nvs_set_u16 (nvs_handle_t handle, uint16_t key, uint16_t value);
nvs_err_t nvs_get_u16 (nvs_handle_t handle, uint16_t key, uint16_t* out_value);
uint16_t nvs_get_u16_or_default(nvs_handle_t handle, uint16_t key, uint16_t default_value);

nvs_err_t nvs_set_i32 (nvs_handle_t handle, uint16_t key, int32_t value);
nvs_err_t nvs_get_i32 (nvs_handle_t handle, uint16_t key, int32_t* out_value);
int32_t nvs_get_i32_or_default(nvs_handle_t handle, uint16_t key, int32_t default_value);

nvs_err_t nvs_set_u32 (nvs_handle_t handle, uint16_t key, uint32_t value);
nvs_err_t nvs_get_u32 (nvs_handle_t handle, uint16_t key, uint32_t* out_value);
uint32_t nvs_get_u32_or_default(nvs_handle_t handle, uint16_t key, uint32_t default_value);

nvs_err_t nvs_get_blob_or_default(nvs_handle_t handle, uint16_t key, uint8_t* out_value, uint32_t* length, const char *default_value);

#ifdef __cplusplus
} // extern "C"
#endif

#endif //ESP_NVS_H
