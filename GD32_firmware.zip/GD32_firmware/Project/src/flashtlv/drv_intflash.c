/*
 * drv_intflash.c
 * @brief 
 * Created on: Aug 16, 2022
 * Author: Yanye
 */

#include "drv_intflash.h"
#include "gd32f3x0.h"
#include "rttypes.h"



// TODO feed watch_dog when ENABLE_WATCHDOG==1

/**
 * erase on-chip data
 *
 * @note It will erase align by erase granularity.
 *
 * @param[in] addr start address, align down to 2K
 * @param[in] pages 
 *
 * @return true: erase success
 */
bool flash_erase(uint32_t addr, uint32_t pages) {
    /* unlock the flash program/erase controller */
    fmc_unlock();

    /* clear all pending flags */
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);
    
    uint32_t start_addr = addr & 0xFFFFFC00;
    
    /* erase the flash pages */
    for(uint32_t i = 0U; i < pages; i++) {
        fmc_page_erase(start_addr + (FMC_PAGE_SIZE * i));
        fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);
    }

    /* lock the main FMC after the erase operation */
    fmc_lock();
    
    return true;
}

/**
 * write flash data (no erase operate)
 *
 * @param[in] addr 写入地址，必须在2字节边界
 * @param[in] size 写入大小，必须2字节对齐
 * @param[in] data 写入数据，指针可以不在2字节边界
 *
 * @return result
 */
bool flash_write(uint32_t addr, uint32_t size, const uint8_t *data) {
    uint16_t halfword;
    fmc_state_enum state;
    
    /* unlock the flash program/erase controller */
    fmc_unlock();

    /* clear all pending flags */
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);
    
    if((uint32_t)data & 0x1u) {
        for(uint32_t i = 0u; i < size; i += sizeof(uint16_t)) {
            halfword = (uint16_t)data[i + 1];
            halfword <<= 8u;
            halfword |= (uint16_t)data[i];
            state = fmc_halfword_program(addr, halfword);
            if(state != FMC_READY) {
                break;
            }
            addr += sizeof(uint16_t);
            fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);
        }
    }else {
        for(uint32_t i = 0u; i < size; i += sizeof(uint16_t)) {
            halfword = *((uint16_t *)(data + i));
            state = fmc_halfword_program(addr, halfword);
            if(state != FMC_READY) {
                break;
            }
            addr += sizeof(uint16_t);
            fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);
        }
    }
    
    /* lock the main FMC after the program operation */
    fmc_lock();

    return true;
}
