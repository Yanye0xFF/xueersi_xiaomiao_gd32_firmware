/*
 * drv_intflash.h
 * @brief 
 * Created on: Aug 16, 2022
 * Author: Yanye
 */

#ifndef DRIVER_DRV_INTFLASH_H_
#define DRIVER_DRV_INTFLASH_H_

#include "stdint.h"
#include "stdbool.h"

#ifdef __cplusplus
extern "C" {
#endif

// flash page size is 1KB
#define FMC_PAGE_SIZE    0x400U

uint32_t flash_wait(uint32_t timeout);

bool flash_erase(uint32_t addr, uint32_t size);

bool flash_write(uint32_t addr, uint32_t size, const uint8_t *data);

// mcu-flash读操作直接访问flash所在的地址空间

#ifdef __cplusplus
}
#endif

#endif /* DRIVER_DRV_INTFLASH_H_ */
