/*
 * Copyright (c) 2006-2024, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2024-03-10     Meco Man     the first version
 */

#ifndef __RT_KLIBC_H__
#define __RT_KLIBC_H__

#include "rttypes.h"

#ifdef __cplusplus
extern "C" {
#endif

void rt_show_version(void);

/* kstdio */
extern int printk(const char *fmt, ...);
extern void rt_kputs(const char *str);

int rt_vsprintf(char *dest, const char *format, va_list arg_ptr);
int rt_vsnprintf(char *buf, uint32_t size, const char *fmt, va_list args);
int rt_sprintf(char *buf, const char *format, ...);
int rt_snprintf(char *buf, uint32_t size, const char *format, ...);

/* kstring */

#ifndef RT_KSERVICE_USING_STDLIB_MEMORY
void *rt_memset(void *src, int c, size_t n);
void *rt_memcpy(void *dest, const void *src, size_t n);
void *rt_memmove(void *dest, const void *src, size_t n);
int32_t rt_memcmp(const void *cs, const void *ct, size_t count);
#endif /* RT_KSERVICE_USING_STDLIB_MEMORY */
char *rt_strdup(const char *s);
size_t rt_strnlen(const char *s, size_t maxlen);
#ifndef RT_KSERVICE_USING_STDLIB
char *rt_strstr(const char *str1, const char *str2);
int32_t rt_strcasecmp(const char *a, const char *b);
char *rt_strcpy(char *dst, const char *src);
char *rt_strncpy(char *dest, const char *src, size_t n);
int32_t rt_strncmp(const char *cs, const char *ct, size_t count);
int32_t rt_strcmp(const char *cs, const char *ct);
size_t rt_strlen(const char *src);
#endif

void *rt_malloc(uint32_t size);
void *rt_realloc(void *ptr, uint32_t newsize);
void *rt_calloc(uint32_t count, uint32_t size);
void rt_free(void *ptr);

#ifdef __cplusplus
}
#endif

#endif /* __RT_KLIBC_H__ */
