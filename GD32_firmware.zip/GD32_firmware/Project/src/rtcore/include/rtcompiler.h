/*
 * Copyright (c) 2006-2024, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2024-01-18     Shell        Separate the compiler porting from rtdef.h
 */
#ifndef __RT_COMPILER_H__
#define __RT_COMPILER_H__

#if defined(__ARMCC_VERSION)        /* ARM Compiler */
#define rt_section(x)               __attribute__((section(x)))
#define rt_used                     __attribute__((used))
#define rt_align(n)                 __attribute__((aligned(n)))
#if __ARMCC_VERSION >= 6010050
#define rt_packed(declare)          declare __attribute__((packed))
#else
#define rt_packed(declare)          declare
#endif
#define rt_weak                     __attribute__((weak))
#define rt_typeof                   __typeof
#define rt_noreturn
#define rt_inline                   static __inline
#define rt_always_inline            rt_inline
#else                              /* Unkown Compiler */
    #error not supported tool chain
#endif /* __ARMCC_VERSION */

#endif /* __RT_COMPILER_H__ */
