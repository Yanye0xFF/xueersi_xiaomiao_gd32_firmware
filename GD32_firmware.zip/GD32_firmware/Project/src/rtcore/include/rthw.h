/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-09-15     xqyjlj       perf rt_hw_interrupt_disable/enable
 * 2023-10-16     Shell        Support a new backtrace framework
 */

#ifndef __RT_HW_H__
#define __RT_HW_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Some macros define
 */
#ifndef HWREG64
#define HWREG64(x)          (*((volatile uint64_t *)(x)))
#endif
#ifndef HWREG32
#define HWREG32(x)          (*((volatile uint32_t *)(x)))
#endif
#ifndef HWREG16
#define HWREG16(x)          (*((volatile uint16_t *)(x)))
#endif
#ifndef HWREG8
#define HWREG8(x)           (*((volatile uint8_t *)(x)))
#endif

//#define BIT(n)              ((uint32_t)0x1u << (n))

#ifdef __cplusplus
}
#endif

#endif
