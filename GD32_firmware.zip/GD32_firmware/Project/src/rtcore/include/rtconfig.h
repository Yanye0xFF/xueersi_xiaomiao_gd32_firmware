/* RT-Core config file */

#ifndef __RTCORE_CFG_H__
#define __RTCORE_CFG_H__

/* Kernel Object */
#define RT_NAME_MAX     16
#define RT_ALIGN_SIZE   4

/* kservice optimization */
#define RT_DEBUG
#define DBG_ENABLE
#define RT_DEBUG_INIT   0
//#define RT_DEBUG_COLOR

#define RT_USING_HEAP

/* Kernel Device Object */
#define RT_USING_CONSOLE
#define RT_CONSOLEBUF_SIZE          128

/* RT-Thread Components */
#define RT_USING_COMPONENTS_INIT
#define RT_USING_USER_MAIN
#define RT_MAIN_THREAD_STACK_SIZE     2048
#define RT_MAIN_THREAD_PRIORITY       24

/* Device Drivers */
#define RT_USING_RTC
#define RT_LIBC_DEFAULT_TIMEZONE   8
#define USE_MAIN_STACK_WATERMARK   1
#define DEBUG_FAULT_RESET          1
#endif
