#ifndef _MYLINK_CRC_H_
#define _MYLINK_CRC_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint16_t crc16_modbus(uint16_t init, const uint8_t *data, uint32_t length);

#ifdef __cplusplus
}
#endif

#endif
