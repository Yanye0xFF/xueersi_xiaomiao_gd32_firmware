#include "crc.h"

static const uint16_t MODBUS_CRC16_LUT[] = {
    0x0000, 0xCC01, 0xD801, 0x1400, 0xF001, 0x3C00, 0x2800, 0xE401,
    0xA001, 0x6C00, 0x7800, 0xB401, 0x5000, 0x9C01, 0x8801, 0x4400
};

uint16_t crc16_modbus(uint16_t init, const uint8_t *buf, uint32_t length) {
    uint8_t ch;
    uint16_t crc = init;
    for (uint32_t i = 0; i < length; i++) {
        ch = buf[i];
        crc = (uint16_t)(MODBUS_CRC16_LUT[(ch ^ crc) & 0x0F] ^ (crc >> 4));
        crc = (uint16_t)(MODBUS_CRC16_LUT[((ch >> 4) ^ crc) & 0x0F] ^ (crc >> 4));
    }
    return crc;
}
