#include "button_service.h"
#include "lv_timer.h"
#include "kerrno.h"
#include "gd32f3x0.h"

#include <stddef.h>
#include "rtklibc.h"

#define BUTTON_TICKS_INTERVAL    5 //ms
#define BUTTON_DEBOUNCE_TICKS    2 //MAX 7 (0 ~ 7)
#define BUTTON_SHORT_TICKS       (200 / BUTTON_TICKS_INTERVAL) // max 255
#define BUTTON_LONG_TICKS        (400 / BUTTON_TICKS_INTERVAL) // max 255
#define BUTTON_PRESS_HOLD_HYST   (120 / BUTTON_TICKS_INTERVAL)
#define PRESS_REPEAT_MAX_NUM     20 /*!< The maximum value of the repeat counter */

static button_object_t btn_obj;
static void button_handler(button_object_t* handle);
static button_event_callback button_event_hook;
    
static lv_timer_t button_read_timer;
static void button_read_timer_callback(lv_timer_t *tm);

static bool button_service_inited = false;

// use fixed driver
static void button_io_init(void) {
    gpio_mode_set(GPIOA, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_15);
}

static int button_io_read(void) {
    int level = (int)gpio_input_bit_get(GPIOA, GPIO_PIN_15);
    return level;
}

void button_service_init(void) {
    
    rt_memset(&btn_obj, 0x0, sizeof(button_object_t));
    button_event_hook = NULL;
    
    btn_obj.hold_hyst = 0;
    btn_obj.active_level = 0;
    btn_obj.button_level = 1;
    btn_obj.button_id = 100;
    
    button_io_init();
    
    button_service_inited = true;
}

void button_service_start(void) {
    if(button_service_inited) {
        lv_timer_create(&button_read_timer, button_read_timer_callback, BUTTON_TICKS_INTERVAL, NULL);
        lv_timer_set_name(&button_read_timer, "button");
    }
}

void button_service_stop(void) {
    lv_timer_delete(&button_read_timer);
}

void button_service_close(void) {
    lv_timer_delete(&button_read_timer);
    button_service_inited = false;
}

uint32_t button_service_control(uint32_t cmd, void *args) {
    return 0;
}

bool button_service_set_event_callback(int btn_id, button_event_callback cbk, void *user_data) {
    if(btn_obj.button_id == btn_id) {
        btn_obj.callback = cbk;
        btn_obj.user_data = user_data;
        return true;
    }
    return false;
}

bool button_service_remove_event_callback(int btn_id) {
    return button_service_set_event_callback(btn_id, NULL, NULL);
}

void button_service_set_event_hook(button_event_callback hook) {
    button_event_hook = hook;
}

static void button_read_timer_callback(lv_timer_t *tm) {
    if(btn_obj.callback != NULL) {
        button_handler(&btn_obj);
    }
}

#define EVENT_CB(ev)    if(handle->callback) handle->callback(handle->button_id, (ev), handle)

/**
  * @brief  Button driver core function, driver state machine.
  * @param  handle: the button handle struct.
  * @retval None
  */
static void button_handler(button_object_t* handle) {
    
	uint8_t read_gpio_level = button_io_read(); //button_dev_default.read(handle->button_id);
    
	//ticks counter working..
	if((handle->state) > 0) handle->ticks++;

	/*------------button debounce handle---------------*/
	if(read_gpio_level != handle->button_level) { //not equal to prev one
		//continue read 1 times same new level change
		if(++(handle->debounce_cnt) >= BUTTON_DEBOUNCE_TICKS) {
			handle->button_level = read_gpio_level;
			handle->debounce_cnt = 0;
		}
	} else { //level not change ,counter reset.
		handle->debounce_cnt = 0;
	}

	/*-----------------State machine-------------------*/
	switch (handle->state) {
	case 0:
		if(handle->button_level == handle->active_level) {	//start press down
            if(button_event_hook) {
                button_event_hook(handle->button_id, BUTTON_EVENT_PRESS_DOWN, handle);
            }
			EVENT_CB(BUTTON_EVENT_PRESS_DOWN);
			handle->ticks = 0;
			handle->repeat = 1;
			handle->state = 1;
		}
		break;

	case 1:
		if(handle->button_level != handle->active_level) { //released press up
			EVENT_CB(BUTTON_EVENT_PRESS_UP);
			handle->ticks = 0;
			handle->state = 2;
		} else if(handle->ticks > BUTTON_LONG_TICKS) {
			EVENT_CB(BUTTON_EVENT_LONG_PRESS_START);
			handle->state = 5;
            handle->hold_hyst = 0;
		}
		break;

	case 2:
		if(handle->button_level == handle->active_level) { //press down again
			EVENT_CB(BUTTON_EVENT_PRESS_DOWN);
			if(handle->repeat < PRESS_REPEAT_MAX_NUM) {
				handle->repeat++;
			}
			EVENT_CB(BUTTON_EVENT_PRESS_REPEAT); // repeat hit
			handle->ticks = 0;
			handle->state = 3;
		} else if(handle->ticks > BUTTON_SHORT_TICKS) { //released timeout
			if(handle->repeat == 1) {
				EVENT_CB(BUTTON_EVENT_SINGLE_CLICK);
			} else if(handle->repeat == 2) {
				EVENT_CB(BUTTON_EVENT_DOUBLE_CLICK); // repeat hit
			}
			handle->state = 0;
		}
		break;

	case 3:
		if(handle->button_level != handle->active_level) { //released press up
			EVENT_CB(BUTTON_EVENT_PRESS_UP);
			if(handle->ticks < BUTTON_SHORT_TICKS) {
				handle->ticks = 0;
				handle->state = 2; //repeat press
			} else {
				handle->state = 0;
			}
		} else if(handle->ticks > BUTTON_SHORT_TICKS) { // SHORT_TICKS < press down hold time < LONG_TICKS
			handle->state = 1;
		}
		break;

	case 5:
		if(handle->button_level == handle->active_level) {
			//continue hold trigger
            handle->hold_hyst++;
            if(handle->hold_hyst >= BUTTON_PRESS_HOLD_HYST) {
                handle->hold_hyst = 0;
                EVENT_CB(BUTTON_EVENT_LONG_PRESS_HOLD);
            }
		} else { //released
			EVENT_CB(BUTTON_EVENT_PRESS_UP);
			handle->state = 0; //reset
		}
		break;
	default:
		handle->state = 0; //reset
		break;
	}
}
