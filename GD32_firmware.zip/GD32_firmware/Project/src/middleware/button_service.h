#ifndef _APP_BUTTON_SERVICE_H_
#define _APP_BUTTON_SERVICE_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// input service
struct _button_object;
typedef struct _button_object button_object_t;

typedef void (*button_event_callback)(uint32_t btn_id, uint32_t event_id, button_object_t *inst);

struct _button_object {
	uint8_t ticks;
	uint8_t repeat;
	uint8_t hold_hyst;
	uint8_t state; // state code 0 ~ 5
    
	uint8_t debounce_cnt;
	uint8_t active_level;
	uint8_t button_level;
	uint8_t button_id;
    
	button_event_callback callback;
    void *user_data;
};

typedef void (*button_init_func)(void);
typedef void (*button_close_func)(void);
typedef uint8_t (*button_read_func)(int btn_id);
typedef uint8_t (*button_active_level_func)(int btn_id);
typedef uint32_t (*button_ioctl_func)(uint32_t cmd, void *args);

typedef struct _button_device {
    const button_init_func init;
    const button_init_func close;
    const button_read_func read;
    const button_active_level_func get_active_level;
    const button_ioctl_func ioctl;
}button_device_t;

#define BUTTON_EVENT_PRESS_DOWN          0u
#define BUTTON_EVENT_PRESS_UP            1u
#define BUTTON_EVENT_PRESS_REPEAT        2u
#define BUTTON_EVENT_SINGLE_CLICK        3u
#define BUTTON_EVENT_DOUBLE_CLICK        4u
#define BUTTON_EVENT_LONG_PRESS_START    5u
#define BUTTON_EVENT_LONG_PRESS_HOLD     6u
#define BUTTON_EVENT_NONE_PRESS          7u

void button_service_init(void);

void button_service_start(void);

void button_service_stop(void);

void button_service_close(void);

uint32_t button_service_control(uint32_t cmd, void *args);

bool button_service_set_event_callback(int btn_id, button_event_callback cbk, void *user_data);

bool button_service_remove_event_callback(int btn_id);

void button_service_set_event_hook(button_event_callback hook);

#ifdef __cplusplus
}
#endif

#endif
