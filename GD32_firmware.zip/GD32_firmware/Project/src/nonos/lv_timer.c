/**
 * @file lv_timer.c
 */

/*********************
 *      INCLUDES
 *********************/
#include "lv_timer.h"
#include "lv_tick.h"
#include "rtklibc.h"
#include <string.h>

/*********************
 *      DEFINES
 *********************/

#define IDLE_MEAS_PERIOD 500 /*[ms]*/
#define DEF_PERIOD 500
#define TIMER_CLOCK_HZ    1000u

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
static bool lv_timer_exec(lv_timer_t * timer);
static uint32_t lv_timer_time_remaining(lv_timer_t * timer);

/**********************
 *  STATIC VARIABLES
 **********************/
static bool lv_timer_run = false;
static uint32_t idle_last = 0;
static volatile bool timer_deleted;
static volatile bool timer_created;

static lv_timer_t lv_timer_root;

/**********************
 *      MACROS
 **********************/
#if LV_USE_LOG && LV_LOG_TRACE_TIMER
    #define TIMER_TRACE(...) LV_LOG_TRACE(__VA_ARGS__)
#else
    #define TIMER_TRACE(...)
#endif

#define LV_LOG_WARN(...)

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

int lv_timer_core_init(void)
{
    memset(&lv_timer_root, 0x00, sizeof(lv_timer_t));

    /*Initially enable the lv_timer handling*/
    lv_timer_enable(true);
    
    return 0;
}

LV_ATTRIBUTE_TIMER_HANDLER uint32_t lv_timer_handler(void)
{
    TIMER_TRACE("begin");

    /*Avoid concurrent running of the timer handler*/
    static bool already_running = false;
    if(already_running) {
        TIMER_TRACE("already running, concurrent calls are not allow, returning");
        return 1;
    }
    already_running = true;

    if(lv_timer_run == false) {
        already_running = false; /*Release mutex*/
        return 1;
    }

    static uint32_t idle_period_start = 0;
    static uint32_t busy_time         = 0;

    uint32_t handler_start = lv_tick_get();

    if(handler_start == 0) {
        static uint32_t run_cnt = 0;
        run_cnt++;
        if(run_cnt > 100) {
            run_cnt = 0;
            LV_LOG_WARN("It seems lv_tick_inc() is not called.");
        }
    }

    /*Run all timer from the list*/
    lv_timer_t * next;
    lv_timer_t * _lv_timer_act;
    do {
        timer_deleted             = false;
        timer_created             = false;
        _lv_timer_act = lv_timer_get_next(&lv_timer_root);

        while(_lv_timer_act != NULL) {
            /*The timer might be deleted if it runs only once ('repeat_count = 1')
             *So get next element until the current is surely valid*/
            next = lv_timer_get_next(_lv_timer_act);

            if(lv_timer_exec(_lv_timer_act)) {
                /*If a timer was created or deleted then this or the next item might be corrupted*/
                if(timer_created || timer_deleted) {
                    TIMER_TRACE("Start from the first timer again because a timer was created or deleted");
                    break;
                }
            }

            _lv_timer_act = next; /*Load the next timer*/
        }
    } while(_lv_timer_act);

    uint32_t time_till_next = LV_NO_TIMER_READY;
    next = lv_timer_get_next(&lv_timer_root);
    while(next) {
        if(!next->paused) {
            uint32_t delay = lv_timer_time_remaining(next);
            // find max delay time
            if(delay < time_till_next)
                time_till_next = delay;
        }

        next = lv_timer_get_next(next); /*Find the next timer*/
    }

    busy_time += lv_tick_elaps(handler_start);
    uint32_t idle_period_time = lv_tick_elaps(idle_period_start);
    if(idle_period_time >= IDLE_MEAS_PERIOD) {
        idle_last         = (busy_time * 100) / idle_period_time;  /*Calculate the busy percentage*/
        idle_last         = idle_last > 100 ? 0 : 100 - idle_last; /*But we need idle time*/
        busy_time         = 0;
        idle_period_start = lv_tick_get();
    }

    already_running = false; /*Release the mutex*/

    TIMER_TRACE("finished (%d ms until the next timer call)", time_till_next);
    return time_till_next;
}

lv_timer_t * lv_timer_create(lv_timer_t *timer, lv_timer_cb_t timer_xcb, uint32_t period, void * user_data)
{
    lv_timer_t * tail_timer = NULL;

    if(timer == &lv_timer_root) {
        return NULL;
    }
    // Check if timer is in the lv_timer_root list
    tail_timer = lv_timer_root.next;
    while(tail_timer != NULL) {
        if(tail_timer == timer) {
            return NULL;
        }
        tail_timer = tail_timer->next;
    }
    // find tail timer
    tail_timer = &lv_timer_root;
    while(tail_timer->next != NULL) {
        tail_timer = tail_timer->next;
    }

    tail_timer->next = timer;
    timer->prev = tail_timer;
    timer->next = NULL;

    timer->period = period;
    timer->timer_cb = timer_xcb;
    timer->repeat_count = -1;
    timer->paused = 0;
    timer->auto_delete = 1;
    timer->last_run = lv_tick_get();
    timer->user_data = user_data;

    timer_created = true;

    return timer;
}

void lv_timer_set_cb(lv_timer_t * timer, lv_timer_cb_t timer_cb)
{
    timer->timer_cb = timer_cb;
}

void lv_timer_set_name(lv_timer_t * timer, const char *name) {
    timer->name = name;
}

void lv_timer_delete(lv_timer_t * timer)
{
    lv_timer_t * current;
    bool timer_in_list = false;
    
    // root timer can't be delete
    if(timer == &lv_timer_root) {
        return;
    }
    // Check if timer is in the lv_timer_root list
    // Start from lv_timer_root.next because lv_timer_root is just a placeholder node
    current = lv_timer_root.next;
    while(current != NULL) {
        if(current == timer) {
            timer_in_list = true;
            break;
        }
        current = current->next;
    }
    // If timer is not in the list, return without doing anything
    if(!timer_in_list) {
        return;
    }
    // check timer is the last timer
    if(timer->next == NULL) {
        timer->prev->next = NULL;
    }else {
        timer->prev->next = timer->next;
        timer->next->prev = timer->prev;
    }
    timer->prev = NULL;
    timer->next = NULL;

    timer_deleted = true;
}

void lv_timer_pause(lv_timer_t * timer)
{
    timer->paused = true;
}

void lv_timer_resume(lv_timer_t * timer)
{
    timer->paused = false;
}

void lv_timer_set_period(lv_timer_t * timer, uint32_t period)
{
    timer->period = period;
}

void lv_timer_ready(lv_timer_t * timer)
{
    timer->last_run = lv_tick_get() - timer->period - 1;
}

void lv_timer_set_repeat_count(lv_timer_t * timer, int32_t repeat_count)
{
    timer->repeat_count = repeat_count;
}

void lv_timer_set_auto_delete(lv_timer_t * timer, bool auto_delete)
{
    timer->auto_delete = auto_delete;
}

void lv_timer_set_user_data(lv_timer_t * timer, void * user_data)
{
    timer->user_data = user_data;
}

void lv_timer_reset(lv_timer_t * timer)
{
    timer->last_run = lv_tick_get();
}

void lv_timer_enable(bool en)
{
    lv_timer_run = en;
}

uint32_t lv_timer_get_idle(void)
{
    return idle_last;
}

lv_timer_t * lv_timer_get_root(void)
{
    return &lv_timer_root;
}

/**
 * Iterate through the timers
 * @param timer NULL to start iteration or the previous return value to get the next timer
 * @return the next timer or NULL if there is no more timer
 */
lv_timer_t * lv_timer_get_next(lv_timer_t * timer)
{
    if(timer == NULL) {
        return NULL;
    }
    return timer->next;
}

LV_ATTRIBUTE_TIMER_HANDLER uint32_t lv_timer_handler_run_in_period(uint32_t period)
{
    static uint32_t last_tick = 0;

    if(lv_tick_elaps(last_tick) >= period) {
        last_tick = lv_tick_get();
        return lv_timer_handler();
    }
    return 1;
}

void * lv_timer_get_user_data(lv_timer_t * timer)
{
    return timer->user_data;
}

bool lv_timer_get_paused(lv_timer_t * timer)
{
    return timer->paused;
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

/**
 * Execute timer if its remaining time is zero
 * @param timer pointer to lv_timer
 * @return true: execute, false: not executed
 */
static bool lv_timer_exec(lv_timer_t * timer)
{
    if(timer->paused) return false;

    bool exec = false;
    if(lv_timer_time_remaining(timer) == 0) {
        /* Decrement the repeat count before executing the timer_cb.
         * If any timer is deleted `if(timer->repeat_count == 0)` is not executed below
         * but at least the repeat count is zero and the timer can be deleted in the next round*/
        int32_t original_repeat_count = timer->repeat_count;
        if(timer->repeat_count > 0) timer->repeat_count--;
        timer->last_run = lv_tick_get();
        TIMER_TRACE("calling timer callback: %p", *((void **)&timer->timer_cb));

        if(timer->timer_cb && original_repeat_count != 0) timer->timer_cb(timer);

        if(!timer_deleted) {
            TIMER_TRACE("timer callback %p finished", *((void **)&timer->timer_cb));
        }
        else {
            TIMER_TRACE("timer callback finished");
        }

        exec = true;
    }

    if(timer_deleted == false) { /*The timer might be deleted by itself as well*/
        if(timer->repeat_count == 0) { /*The repeat count is over, delete the timer*/
            if(timer->auto_delete) {
                TIMER_TRACE("deleting timer with %p callback because the repeat count is over", *((void **)&timer->timer_cb));
                lv_timer_delete(timer);
            }
            else {
                TIMER_TRACE("pausing timer with %p callback because the repeat count is over", *((void **)&timer->timer_cb));
                lv_timer_pause(timer);
            }
        }
    }

    return exec;
}

/**
 * Find out how much time remains before a timer must be run.
 * @param timer pointer to lv_timer
 * @return the time remaining, or 0 if it needs to be run again
 */
static uint32_t lv_timer_time_remaining(lv_timer_t * timer)
{
    /*Check if at least 'period' time elapsed*/
    uint32_t elp = lv_tick_elaps(timer->last_run);
    if(elp >= timer->period)
        return 0;
    return timer->period - elp;
}
